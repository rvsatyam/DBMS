<?php
    $conn= new mysqli("localhost","root","","hospitalProject");


      // Check connection
      if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // sql to delete a record
    $sql = "SELECT SUM(Salary) AS D FROM Doctor";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result);
    $f = $row['D'];
    $pp = "SELECT SUM(Salary) AS C FROM Caretaker";
    $res = mysqli_query($conn, $pp);
    $col = mysqli_fetch_array($res);
    $s = $col['C'];
    echo "Total Salary of Doctors and Caretakers is ";
    echo $f + $s;

    mysqli_close($conn);

  ?>
