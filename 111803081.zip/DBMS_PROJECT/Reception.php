<?php
  $Reception_ID = $_POST['Reception_ID'];
  $Name_of_Patient = $_POST['Name_of_Patient'];
  $Telephone = $_POST['Telephone'];
  $Date = $_POST['Date'];
  $Patient_ID = $_POST['Patient_ID'];
  
  
  $conn = new mysqli('localhost', 'root', '', 'hospitalProject');
  if($conn->connect_error){
    die('Connection Failed :'.$conn->connect_error);
  }
  else{
    $stmt = $conn->prepare("insert into Reception( Reception_ID , Name_of_Patient ,Telephone ,Date ,Patient_ID) values(?,?,?,?,?)");
    $stmt->bind_param("isisi", $Reception_ID , $Name_of_Patient ,$Telephone ,$Date ,$Patient_ID );
    $stmt->execute();
    echo "registeration succesfully";
    $stmt->close();
    $conn->close();
  }
?>
