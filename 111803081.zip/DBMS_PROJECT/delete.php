<?php
    $conn= new mysqli("localhost","root","","hospitalProject");


    if(isset($_POST['Patient_ID'])){
      //$query = "SELECT * FROM employees
     // WHERE first_name LIKE '%{$name}%' OR last_name LIKE '%{$name}%'";
     $Patient_ID = $_POST['Patient_ID'];
      // Check connection
      if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // sql to delete a record
    $sql = "DELETE FROM Reception WHERE Patient_ID='$Patient_ID'";

    if ($conn->query($sql) === TRUE) {
      $sql = "DELETE FROM Patient WHERE ID='$Patient_ID'";

      if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
      } else {
        echo "Error deleting record: " . $conn->error;
      }
    }
    else {
      echo "Error deleting record: " . $conn->error;
    }

    $conn->close();
  }
  else if(isset($_POST['Doctor_ID'])){
    $Doctor_ID = $_POST['Doctor_ID'];
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // sql to delete a record
  $sql = "DELETE FROM Doctor WHERE ID='$Doctor_ID'";

  if ($conn->query($sql) === TRUE) {
    echo "Record deleted succesfully!!!";
    }
    else {
      echo "Error deleting record: " . $conn->error;
    }

    $conn->close();
  }


  ?>
