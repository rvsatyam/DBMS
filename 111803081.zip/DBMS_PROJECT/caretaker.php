<?php
		extract($_POST);
		$Name = $_POST['Name'];
		$Employee_ID = $_POST['Employee_ID'];
		$Age = $_POST['Age'];
		$Address = $_POST['Address'];
	 $Salary = $_POST['Salary'];
		$Telephone = $_POST['Telephone'];

		$conn = new mysqli('localhost', 'root', '', 'hospitalProject');
		if($conn->connect_error){
			die('Connection Failed :'.$conn->connect_error);
		}
		else{
			$stmt = $conn->prepare("insert into Caretaker(Name, Employee_ID, Age, Address, Salary, Telephone)values(?,?,?, ?,?,?)");
			$stmt->bind_param('siisii', $Name, $Employee_ID, $Age, $Address, $Salary, $Telephone);
			$stmt->execute();
			echo "registeration succesfully";
			$stmt->close();
			$conn->close();
		}
	?>
