<?php
  $Name = $_POST['Name'];
  $ID = $_POST['ID'];
  $Age = $_POST['Age'];
  $Address = $_POST['Address'];
  $Date_of_Admission = $_POST['Date_of_Admission'];
  $Telephone = $_POST['Telephone'];
  $Caretaker_ID = $_POST['Caretaker_ID'];
  $Transaction_ID = $_POST['Transaction_ID'];
  $Diagnosis_number = $_POST['Diagnosis_number'];
  $Charge = $_POST['Charge'];
  $conn = new mysqli('localhost', 'root', '', 'hospitalProject');
  if($conn->connect_error){
    die('Connection Failed :'.$conn->connect_error);
  }
  else{
    $stmt = $conn->prepare("insert into Patient(Name, ID, Age, Address, Date_of_Admission, Telephone, Caretaker_ID, Transaction_ID, Diagnosis_number, Charge)values(?,?, ?,?,?,?,?,?,?,?)");
    $stmt->bind_param("siissiiiii", $Name, $ID, $Age, $Address, $Date_of_Admission, $Telephone, $Caretaker_ID, $Transaction_ID, $Diagnosis_number, $Charge);
    $stmt->execute();
    echo "registeration succesfully";
    $stmt->close();
    $conn->close();
  }
?>
