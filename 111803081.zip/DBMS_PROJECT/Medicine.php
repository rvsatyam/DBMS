<?php
  $Registered_medicine_number = $_POST['Registered_medicine_number'];
  $Name = $_POST['Name'];
  $Company = $_POST['Company'];
  $Price = $_POST['Price'];
  
  $conn = new mysqli('localhost', 'root', '', 'hospitalProject');
  if($conn->connect_error){
    die('Connection Failed :'.$conn->connect_error);
  }
  else{
    $stmt = $conn->prepare("insert into Medicine( Registered_medicine_number , Name , Company , Price ) values(?,?,?,?)");
    $stmt->bind_param("issi", $Registered_medicine_number , $Name , $Company , $Price );
    $stmt->execute();
    echo "registeration succesfully";
    $stmt->close();
    $conn->close();
  }
?>
