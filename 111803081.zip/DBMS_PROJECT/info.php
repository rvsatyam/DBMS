<?php
    $conn= new mysqli("localhost","root","","hospitalProject");

    //$query = "SELECT * FROM employees
   // WHERE first_name LIKE '%{$name}%' OR last_name LIKE '%{$name}%'";
   if(isset($_POST['Patient_ID'])){
     $Patient_ID = $_POST['Patient_ID'];
      // Check connection
      if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $sql = "SELECT * FROM Patient WHERE ID='$Patient_ID'";
  $result = mysqli_query($conn, $sql);
  if($result->num_rows > 0){
    // output data of each row
    while($row = mysqli_fetch_array($result)) {
      echo "Name, " .$row['Name'];
      echo "</br>";
      echo "ID  " .$row['ID'];
      echo "</br>";
      echo "Age,  ". $row['Age'];
      echo "</br>";
      echo "Address,  ".$row['Address'];
      echo "</br>";
      echo "Date_of_Admission,  ".$row['Date_of_Admission'];
      echo "</br>";
      echo " Telephone, ". $row['Telephone'];
      echo "</br>";
      echo "Caretaker_ID, ". $row['Caretaker_ID'];
      echo "</br>";
      echo "Transaction_ID, " . $row['Transaction_ID'];
      echo "</br>";
      echo "Diagnosis_number,   ".$row['Diagnosis_number'];
      echo "</br>";
      echo "Charge  ".  $row['Charge'];
      echo "</br>";
    }
  }
    else{
      echo "<h1>No Patient Found!!</h1>";
    }

  mysqli_close($conn);
   }
   else if(isset($_POST['Doctor_ID'])){
     $Doctor_ID = $_POST['Doctor_ID'];
      // Check connection
      if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $sql = "SELECT * FROM Doctor WHERE ID='$Doctor_ID'";
  $result = mysqli_query($conn, $sql);
  if($result->num_rows > 0){
    // output data of each row
    while($row = mysqli_fetch_array($result)) {
      echo "Name, " .$row['Name'];
      echo "</br>";
      echo "ID  " .$row['ID'];
      echo "</br>";
      echo "Designation,  ". $row['Designation'];
      echo "</br>";
      echo "Address,  ".$row['Address'];
      echo "</br>";
      echo " Salary,  ".$row['Salary'];
      echo "</br>";
      echo "Caretaker_ID, ". $row['Caretaker_ID'];
      echo "</br>";
    }
  }
    else{
      echo "<h1>No Doctor Found!!</h1>";
    }
    $sql = "SELECT Diagnosis_number, Date FROM Diagnosis WHERE Doctor_ID='$Doctor_ID'";
    $result = mysqli_query($conn, $sql);
    if($result->num_rows > 0){
      // output data of each row
      while($row = mysqli_fetch_array($result)) {
        echo "Diagnosis_number, " .$row['Diagnosis_number'];
        echo "  ";
        echo "Date  " .$row['Date'];
        echo "</br>";
      }
    }
      else{
        echo "<h1>No Doctor Found!!</h1>";
      }
      $sql = "SELECT COUNT(Diagnosis_number) AS DN FROM Diagnosis WHERE Doctor_ID='$Doctor_ID'";
      $result = mysqli_query($conn, $sql);
      if($result->num_rows > 0){
        // output data of each row
        while($row = mysqli_fetch_array($result)) {
          echo "Total Number of Appointements till Date " .$row['DN'];
          echo "</br>";
        }
      }
        else{
          echo "<h1>No Doctor Found!!</h1>";
        }
  mysqli_close($conn);
   }
?>
