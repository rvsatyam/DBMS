<?php
  $Diagnosis_number = $_POST['Diagnosis_number'];
  $Doctor_ID = $_POST['Doctor_ID'];
  $Patient_ID = $_POST['Patient_ID'];
  $Registered_medicine = $_POST['Registered_medicine'];
  $Date = $_POST['Date_of_Admission'];
  $Charge_of_Diagnosis = $_POST['Charge_of_Diagnosis'];

  $conn = new mysqli('localhost', 'root', '', 'hospitalProject');
  if($conn->connect_error){
    die('Connection Failed :'.$conn->connect_error);
  }
  else{
    $stmt = $conn->prepare("insert into Diagnosis( Diagnosis_number, Doctor_ID, Patient_ID, Registered_medicine, Charge_of_Diagnosis , Date) values(?,?, ?,?,?,?)");
    $stmt->bind_param("iiisis", $Diagnosis_number, $Doctor_ID, $Patient_ID, $Registered_medicine, $Charge_of_Diagnosis, $Date );
    $stmt->execute();
    echo "registeration succesfully";
    $stmt->close();
    $conn->close();
  }
?>
