<?php
  $Transaction_ID = $_POST['Transaction_ID'];
  $Doctor_ID = $_POST['Doctor_ID'];
  $Patient_ID = $_POST['Patient_ID'];
  $Amount = $_POST['Amount'];
  $Payment_Date = $_POST['Payment_Date'];
  $Balance= $_POST['Balance'];
  
  $conn = new mysqli('localhost', 'root', '', 'hospitalProject');
  if($conn->connect_error){
    die('Connection Failed :'.$conn->connect_error);
  }
  else{
    $stmt = $conn->prepare("insert into Bills( Transaction_ID , Doctor_ID , Patient_ID , Amount , Payment_Date , Balance ) values(?,?, ?,?,?,?)");
    $stmt->bind_param("iiiisi", $Transaction_ID , $Doctor_ID , $Patient_ID , $Amount , $Payment_Date , $Balance);
    $stmt->execute();
    echo "registeration succesfully";
    $stmt->close();
    $conn->close();
  }
?>
