<?php
    $conn= new mysqli("localhost","root","","hospitalProject");


      // Check connection
      if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // sql to delete a record
    $sql = "SELECT SUM(Balance) AS T FROM Bills";

    $result = mysqli_query($conn, $sql);
    while($row = mysqli_fetch_array($result)) {
      echo "<h1>Total of Bills </h1>". $row['T'];
      echo "</br>";
    }

    mysqli_close($conn);

  ?>
