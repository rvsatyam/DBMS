<?php
  $username = $_POST['username'];
  $password = $_POST['password'];
  if( $username == 'Patient' && $password == 1234)
    echo file_get_contents('patient.html');
  elseif ($username == 'Doctor' && $password == 2345) {
    echo file_get_contents('doctor.html');
  }
  elseif ($username == 'Reception' && $password == 3456) {
    echo file_get_contents('reception.html');
  }
  elseif ($username == 'Caretaker' && $password == 4567) {
    echo file_get_contents('caretaker.html');
  } else{
    echo file_get_contents('home.html');
  }
?>
