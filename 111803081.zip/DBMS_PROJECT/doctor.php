<?php
  $Name = $_POST['Name'];
  $ID = $_POST['ID'];
  $Designation = $_POST['Designation'];
  $Address = $_POST['Address'];
  $Salary = $_POST['Salary'];
  $Caretaker_ID = $_POST['Caretaker_ID'];

  $conn = new mysqli('localhost', 'root', '', 'hospitalProject');
  if($conn->connect_error){
    die('Connection Failed :'.$conn->connect_error);
  }
  else{
    $stmt = $conn->prepare("insert into Doctor(Name, ID, Designation, Address, Salary , Caretaker_ID ) values(?,?, ?,?,?,?)");
    $stmt->bind_param("sissii", $Name, $ID,$Designation, $Address,$Salary, $Caretaker_ID );
    $stmt->execute();
    echo "registeration succesfully";
    $stmt->close();
    $conn->close();
  }
?>
