Hello!
For ensuring the hospital database management systems working efficiently,
first of all you needd to recruite new staff, i.e. Add Data of the caretakersvto the Databases,
also add the Medicines to hospital i.e. Add the data of Medicines in the Database

Then you may recruit new doctors at different designation as per their knowledge, assign different Caretaker under them guidance to help the patients.

After that you may start diagnosis o fthe Patients, i.e add the details of the diagnosis to the database.

Once the diagnosis is done then you may add the details of the bills i.e. add the data of the bills to the database.

Thus after that you can add information of the Patient to the Database, once the diagnosis and medication is over !!!
and then at the reception while discharging , the patient information will be filled in the Reception Database.!!!

I hope this helps you !!!

